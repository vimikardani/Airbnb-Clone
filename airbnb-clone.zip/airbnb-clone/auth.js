const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

// Mock database for users (replace this with a real database)
const users = [];

// Register endpoint - Mock registration (add user to 'users' array)
app.post('/register', async (req, res) => {
    try {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10); // Hash password

        // Add user to the database (in this case, 'users' array)
        users.push({ id: users.length + 1, username, password: hashedPassword });
        res.status(201).send('User registered successfully');
    } catch (error) {
        res.status(500).send('Error registering user');
    }
});

// Login endpoint
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Find user in 'users' array (replace this with a database query)
    const user = users.find((user) => user.username === username);
    if (!user) {
        return res.status(404).send('User not found');
    }

    // Check if the provided password matches the stored hashed password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
        return res.status(401).send('Invalid password');
    }

    // Create and assign a token for authentication
    const token = jwt.sign({ id: user.id }, 'secretKey',{expiresIn: '1h'});
    res.cookie('authToken', token, { httpOnly: true }); // Set a cookie with the token

    res.status(200).send('Login successful');
});

// Protected route example
app.get('/protected', authenticateToken, (req, res) => {
    res.send('Protected route accessed');
});

// Middleware to authenticate tokens
function authenticateToken(req, res, next) {
    const token = req.cookies.authToken;

    if (!token) {
        return res.status(401).send('Unauthorized');
    }

    jwt.verify(token, 'secretKey', (err, decoded) => {
        if (err) {
            return res.status(403).send('Invalid token');
        }
        req.user = decoded;
        next();
    });
}



app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

