const mongoose=require('mongoose');
const passportLocalMongoose = require("passport-local-mongoose");

// Registered user scheme
const userSchema=new mongoose.Schema({
    
        firstname: { 
            type: String,
            required:true,
            minlength: 3,
            maxlength: 30
        },
        lastname: { 
            type: String,
            required:true,
            minlength: 3,
            maxlength: 30 
        },
        email:{  
            type: String,
            required: true,
            unique: true,
            minlength: 12,
            maxlength: 50
        },
        password:{  
            type: String,
            required: true,
            minlength: 6,
            maxlength: 255 
        },
    
})

userSchema.plugin(passportLocalMongoose);

module.exports=new mongoose.model("User",userSchema)