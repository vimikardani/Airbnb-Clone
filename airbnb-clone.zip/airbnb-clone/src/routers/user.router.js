const express=require('express');
const router=express.Router();


const {loginpage,registrationpage,registerUser,loginUser}=require("../controllers/user.controller");

router.get("/login", loginpage);

router.get("/registration",registrationpage);

router.post("/registration",registerUser);

router.post("/login",loginUser);

router.post('/logout', function(req, res, next) {
    req.logout(function(err) {
      if (err) { return next(err); }
      res.redirect('/');
    });
  });
module.exports=router;