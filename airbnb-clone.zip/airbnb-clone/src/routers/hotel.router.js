const express=require('express');
const router=express.Router();
const {getallHoteldata,addhoteldata,findhotelId,deleteHotel}=require('../controllers/hotel.controller')

router.get("/",getallHoteldata);

router.post("/addhotel",addhoteldata);

router.get("/:id",findhotelId);

router.get('/deletehotel/:id',deleteHotel);



module.exports=router;

