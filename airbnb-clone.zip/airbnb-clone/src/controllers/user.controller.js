// const express=require('express');
const User = require('../models/user.model');
const bcrypt = require("bcrypt");
const Hotel=require("../models/hotel.model");
// const cookieParser =require('cookie-parser');
// const jwt=require('jsonwebtoken');

// const app=express();
// app.use(cookieParser());

// render loginpage
const loginpage = (req, res) => {
    res.render("login")
}

// render registration page
const registrationpage = (req, res) => {
    res.render("registration")
}

// registered user validations
const registerUser = async (req, res) => {
    try {

        const { firstname, lastname, email, password } = req.body;

        // validation on required fields
        if (!firstname || !lastname || !email || !password) {
            res.status(400).send('All fields are required')
        }

        // validation on already registered user
        const checkUser = await User.findOne({ email });
        if (checkUser) {
            res.status(400).send('User already registered')
        }

        // password bcrypt

        const salt=await bcrypt.genSalt(10);
        const hashPassword=await bcrypt.hash(password, salt);

        // create user
        const user = await User.create({ firstname, lastname, email, password: hashPassword});
        res.status(200).render("login");

    } catch (error) {
        res.send(error);
    }

}

// login user validations
const loginUser = async (req, res) => {

    try {

        const { email, password } = req.body;

        // required field validation
        if (!email || !password) {
            res.status(400).send('All fields are required')
        }

        // validation for find and access registered user
        const user = await User.findOne({ email }, "password");

        if (!user) {
            res.status(404).send('Email is not registered')
        }

        // compare bcrypt password with actual password

        if (user && (await bcrypt.compare(password,user.password))) {
            const allHotel= await Hotel.find();
            res.render("home",{allHoteldata:allHotel});
        }
        else {
            res.status(400).send("Invalid email or password");
        }

        
    }
    catch (error) {
        res.send(error);
    }
}

module.exports = { loginpage, registrationpage, registerUser, loginUser}